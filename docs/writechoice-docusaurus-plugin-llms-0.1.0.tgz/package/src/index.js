// @ts-check
const path = require('path');
const fs = require('fs').promises;

/** @typedef {{ title: string; description?: string }} DocMeta */

/**
 * @param {import('@docusaurus/types').LoadContext} context
 * @param {Record<string, unknown>} options
 * @returns {import('@docusaurus/types').Plugin}
 */
module.exports = function llmsPlugin(context, options) {
  const { siteConfig, siteDir } = context;

  const opts = {
    /** Generate /llms.txt at build output root */
    generateLlmsTxt: true,
    /** Copy source .md files so /path/to/page.md is accessible */
    generateMarkdownFiles: true,
    /** ChatGPT base URL for "Open in ChatGPT" */
    chatgptUrl: 'https://chatgpt.com/',
    /** Claude base URL for "Open in Claude" */
    claudeUrl: 'https://claude.ai/new',
    ...options,
  };

  return {
    name: 'docusaurus-plugin-llms',

    getThemePath() {
      return path.resolve(__dirname, './theme');
    },

    getClientModules() {
      return [];
    },

    async postBuild({ outDir, routesPaths, allContent }) {
      const tasks = [];

      if (opts.generateLlmsTxt) {
        tasks.push(
          generateLlmsTxt(siteConfig, outDir, routesPaths, allContent).catch((e) =>
            console.warn('[docusaurus-plugin-llms] llms.txt generation failed:', e.message),
          ),
        );
      }

      if (opts.generateMarkdownFiles) {
        tasks.push(
          copyMarkdownFiles(siteDir, outDir, allContent).catch((e) =>
            console.warn('[docusaurus-plugin-llms] Markdown file copy failed:', e.message),
          ),
        );
      }

      await Promise.all(tasks);
    },
  };
};

// Allow `import plugin from '...'` in ESM contexts (e.g. docusaurus.config.ts)
module.exports.default = module.exports;

// ---------------------------------------------------------------------------
// llms.txt generation
// ---------------------------------------------------------------------------

/**
 * @param {import('@docusaurus/types').DocusaurusConfig} siteConfig
 * @param {string} outDir
 * @param {string[]} routesPaths
 * @param {Record<string, unknown>} allContent
 */
async function generateLlmsTxt(siteConfig, outDir, routesPaths, allContent) {
  const docMap = buildDocMap(allContent);

  const lines = [`# ${siteConfig.title}`];

  if (siteConfig.tagline) {
    lines.push('', `> ${siteConfig.tagline}`);
  }

  lines.push('', '## Pages', '');

  const sorted = [...routesPaths].sort();
  for (const routePath of sorted) {
    // Skip build artifacts that are not real pages
    if (routePath === '/404.html' || routePath.endsWith('.html')) continue;

    const doc = docMap.get(routePath);
    if (doc) {
      const desc = doc.description ? `: ${doc.description}` : '';
      lines.push(`- [${doc.title}](${siteConfig.url}${routePath})${desc}`);
    } else {
      lines.push(`- ${siteConfig.url}${routePath}`);
    }
  }

  const content = lines.join('\n') + '\n';
  await fs.writeFile(path.join(outDir, 'llms.txt'), content, 'utf8');
  console.log('[docusaurus-plugin-llms] Generated llms.txt');
}

// ---------------------------------------------------------------------------
// .md file copy
// ---------------------------------------------------------------------------

/**
 * @param {string} siteDir
 * @param {string} outDir
 * @param {Record<string, unknown>} allContent
 */
async function copyMarkdownFiles(siteDir, outDir, allContent) {
  const docs = collectDocs(allContent);
  let copied = 0;

  await Promise.all(
    docs.map(async ({ source, permalink }) => {
      if (!source || !permalink) return;

      // source is like "@site/docs/intro.md"
      const sourcePath = source.replace(/^@site/, siteDir);

      // Destination: {outDir}{permalink}.md
      // Normalise double slashes and ensure the dir exists
      const destPath = path.join(outDir, permalink.replace(/\/+$/, '') + '.md');
      const destDir = path.dirname(destPath);

      try {
        await fs.mkdir(destDir, { recursive: true });
        await fs.copyFile(sourcePath, destPath);
        copied++;
      } catch {
        // Best-effort; skip files that can't be resolved
      }
    }),
  );

  console.log(`[docusaurus-plugin-llms] Copied ${copied} markdown files`);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Build a Map<permalink, DocMeta> from allContent.
 * Handles docs plugin with single or multiple instances.
 * @param {Record<string, unknown>} allContent
 * @returns {Map<string, DocMeta>}
 */
function buildDocMap(allContent) {
  /** @type {Map<string, DocMeta>} */
  const map = new Map();

  for (const doc of collectDocs(allContent)) {
    if (doc.permalink) {
      map.set(doc.permalink, { title: doc.title ?? doc.permalink, description: doc.description });
    }
  }

  return map;
}

/**
 * Flatten all docs from all docs-plugin instances into a single array.
 * @param {Record<string, unknown>} allContent
 * @returns {Array<{ permalink?: string; title?: string; description?: string; source?: string }>}
 */
function collectDocs(allContent) {
  /** @type {ReturnType<typeof collectDocs>} */
  const result = [];

  const docsPluginContent = /** @type {Record<string, any>} */ (
    allContent?.['docusaurus-plugin-content-docs']
  );
  if (!docsPluginContent) return result;

  for (const pluginInstance of Object.values(docsPluginContent)) {
    for (const version of pluginInstance?.loadedVersions ?? []) {
      for (const doc of version?.docs ?? []) {
        result.push(doc);
      }
    }
  }

  return result;
}
