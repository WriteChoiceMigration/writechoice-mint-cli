import React, { useState, useCallback, useRef, useEffect } from 'react';
import { useLocation } from '@docusaurus/router';
import useDocusaurusContext from '@docusaurus/useDocusaurusContext';
import styles from './styles.module.css';

// ---------------------------------------------------------------------------
// Icons
// ---------------------------------------------------------------------------

function IconCopy() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
    </svg>
  );
}

function IconMarkdown() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <rect x="2" y="6" width="20" height="12" rx="2" />
      <path d="M6 12h4l2-2 2 2h4" />
      <path d="M14 12v4" />
    </svg>
  );
}

function IconChatGPT() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M22.28 9.38a5.5 5.5 0 0 0-.48-4.52 5.57 5.57 0 0 0-5.97-2.67A5.5 5.5 0 0 0 11.7 0a5.57 5.57 0 0 0-5.3 3.86 5.5 5.5 0 0 0-3.67 2.67 5.57 5.57 0 0 0 .68 6.52 5.5 5.5 0 0 0 .48 4.52 5.57 5.57 0 0 0 5.97 2.67A5.5 5.5 0 0 0 13 24a5.57 5.57 0 0 0 5.3-3.86 5.5 5.5 0 0 0 3.67-2.67 5.57 5.57 0 0 0-.69-6.09zM13 22.5a4.1 4.1 0 0 1-2.63-.95l.13-.07 4.36-2.52a.73.73 0 0 0 .36-.63v-6.15l1.84 1.07a.07.07 0 0 1 .04.05v5.1A4.12 4.12 0 0 1 13 22.5zm-8.8-3.78a4.1 4.1 0 0 1-.49-2.75l.13.08 4.36 2.52a.73.73 0 0 0 .72 0l5.32-3.08v2.14a.07.07 0 0 1-.03.06L9.85 20.2a4.12 4.12 0 0 1-5.65-1.48zm-1.14-9.55a4.08 4.08 0 0 1 2.13-1.8v5.18a.73.73 0 0 0 .36.63l5.32 3.07-1.84 1.06a.07.07 0 0 1-.07 0L4.7 14.9a4.12 4.12 0 0 1-.64-5.73zm15.13 3.54-5.32-3.08 1.84-1.06a.07.07 0 0 1 .07 0l4.29 2.48a4.1 4.1 0 0 1-.64 7.4V12.8a.73.73 0 0 0-.24-.59zm1.83-2.77-.13-.08-4.36-2.52a.73.73 0 0 0-.72 0L9.49 11.4V9.27a.07.07 0 0 1 .03-.06l4.29-2.48a4.12 4.12 0 0 1 6.21 4.21zM8.4 12.89l-1.84-1.06a.07.07 0 0 1-.04-.05V6.68A4.12 4.12 0 0 1 13.17 3.6l-.13.07-4.36 2.52a.73.73 0 0 0-.36.63l.08 6.07zm1-2.16 2.37-1.37 2.37 1.37v2.73l-2.37 1.37-2.37-1.37v-2.73z" />
    </svg>
  );
}

function IconClaude() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M12 2.25c-.69 0-1.35.12-1.97.35L12 6.37l1.97-3.77A9.77 9.77 0 0 0 12 2.25zm3.57 1.18-2.4 4.6 4.97-1.33a9.75 9.75 0 0 0-2.57-3.27zm-7.14 0a9.75 9.75 0 0 0-2.57 3.27l4.97 1.33-2.4-4.6zM4.08 8.06A9.74 9.74 0 0 0 3 12c0 .6.06 1.18.17 1.74l4.54-2.14-3.63-3.54zM20.83 13.74c.11-.56.17-1.14.17-1.74 0-1.46-.32-2.85-.92-4.1l-3.54 3.62 4.29 2.22zM7.42 14.3l-4.1 1.94a9.76 9.76 0 0 0 2.4 3.09l2.56-4.9-.86-.13zm9.16 0-.86.13 2.56 4.9a9.76 9.76 0 0 0 2.4-3.09l-4.1-1.94zm-4.95.53-2.42 4.64c.57.21 1.17.35 1.79.39V15.7l.63-.87zm1.74 0-.63.87v3.63c.62-.04 1.22-.18 1.79-.39l-2.16-4.11z" />
    </svg>
  );
}

function IconChevron({ open }) {
  return (
    <svg
      width="12"
      height="12"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      style={{ transform: open ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.15s ease' }}
    >
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

function IconExternalLink() {
  return (
    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{ marginLeft: 3, verticalAlign: 'middle', opacity: 0.7 }}>
      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
      <polyline points="15 3 21 3 21 9" />
      <line x1="10" y1="14" x2="21" y2="3" />
    </svg>
  );
}

// ---------------------------------------------------------------------------
// Dropdown item
// ---------------------------------------------------------------------------

function DropdownItem({ icon, label, description, onClick, href }) {
  const inner = (
    <>
      <span className={styles.itemIcon}>{icon}</span>
      <span className={styles.itemText}>
        <span className={styles.itemLabel}>
          {label}
          {href && <IconExternalLink />}
        </span>
        <span className={styles.itemDesc}>{description}</span>
      </span>
    </>
  );

  if (href) {
    return (
      <a
        className={styles.dropdownItem}
        href={href}
        target="_blank"
        rel="noopener noreferrer"
      >
        {inner}
      </a>
    );
  }

  return (
    <button className={styles.dropdownItem} type="button" onClick={onClick}>
      {inner}
    </button>
  );
}

// ---------------------------------------------------------------------------
// Main toolbar
// ---------------------------------------------------------------------------

/**
 * LLMSToolbar — split "Copy page" button + dropdown with LLM options.
 *
 * @param {{ className?: string }} props
 */
export default function LLMSToolbar({ className }) {
  const [open, setOpen] = useState(false);
  const [copyState, setCopyState] = useState(/** @type {'idle'|'copying'|'done'|'error'} */ ('idle'));
  const containerRef = useRef(null);
  const location = useLocation();
  const { siteConfig } = useDocusaurusContext();

  const pathname = location.pathname.replace(/\/$/, '') || '/';
  const mdUrl = `${pathname}.md`;
  const pageUrl = `${siteConfig.url}${pathname}`;

  // Close dropdown on outside click / focus
  useEffect(() => {
    if (!open) return;
    const handler = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    document.addEventListener('focusin', handler);
    return () => {
      document.removeEventListener('mousedown', handler);
      document.removeEventListener('focusin', handler);
    };
  }, [open]);

  const copyMarkdown = useCallback(async () => {
    if (copyState === 'copying') return;
    setCopyState('copying');
    setOpen(false);

    try {
      let text = pageUrl;

      const res = await fetch(mdUrl);
      if (res.ok) {
        text = await res.text();
      }

      await navigator.clipboard.writeText(text);
      setCopyState('done');
    } catch {
      setCopyState('error');
    }

    setTimeout(() => setCopyState('idle'), 2000);
  }, [copyState, mdUrl, pageUrl]);

  const copyLabel =
    copyState === 'copying' ? 'Copying…'
    : copyState === 'done'    ? 'Copied!'
    : copyState === 'error'   ? 'Failed'
    : 'Copy page';

  const chatgptHref = `https://chatgpt.com/?q=${encodeURIComponent(pageUrl)}`;
  const claudeHref = `https://claude.ai/new?q=${encodeURIComponent(pageUrl)}`;

  return (
    <div ref={containerRef} className={`${styles.toolbar} ${className ?? ''}`}>
      <div className={styles.buttonGroup}>
        <button
          type="button"
          className={styles.mainButton}
          onClick={copyMarkdown}
          title="Copy this page as Markdown"
          disabled={copyState === 'copying'}
        >
          <IconCopy />
          <span>{copyLabel}</span>
        </button>

        <div className={styles.divider} aria-hidden="true" />

        <button
          type="button"
          className={styles.chevronButton}
          onClick={() => setOpen((v) => !v)}
          aria-haspopup="true"
          aria-expanded={open}
          aria-label="More LLM options"
        >
          <IconChevron open={open} />
        </button>
      </div>

      {open && (
        <div className={styles.dropdown} role="menu">
          <DropdownItem
            icon={<IconCopy />}
            label="Copy page"
            description="Copy page as Markdown for LLMs"
            onClick={copyMarkdown}
          />
          <DropdownItem
            icon={<IconMarkdown />}
            label="View as Markdown"
            description="View this page as plain text"
            href={mdUrl}
          />
          <DropdownItem
            icon={<IconChatGPT />}
            label="Open in ChatGPT"
            description="Ask questions about this page"
            href={chatgptHref}
          />
          <DropdownItem
            icon={<IconClaude />}
            label="Open in Claude"
            description="Ask questions about this page"
            href={claudeHref}
          />
        </div>
      )}
    </div>
  );
}
