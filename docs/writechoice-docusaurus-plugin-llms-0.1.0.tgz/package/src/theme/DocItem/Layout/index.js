import React from 'react';
import OriginalLayout from '@theme-original/DocItem/Layout';
import LLMSToolbar from '@theme/LLMSToolbar';
import styles from './styles.module.css';

export default function DocItemLayout(props) {
  return (
    <div className={styles.wrapper}>
      <div className={styles.toolbarRow}>
        <LLMSToolbar />
      </div>
      <OriginalLayout {...props} />
    </div>
  );
}
