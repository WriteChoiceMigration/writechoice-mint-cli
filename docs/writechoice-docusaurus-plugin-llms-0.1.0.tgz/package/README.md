# @writechoice/docusaurus-plugin-llms

A Docusaurus plugin + theme that makes your documentation AI-friendly.

- Generates `/llms.txt` — a machine-readable index of all your pages
- Serves every doc page as raw Markdown at `/{path}.md`
- Adds a **Copy page** toolbar button to every doc with a dropdown for LLM tools

![Toolbar screenshot](./docs/toolbar-preview.png)

---

## Features

### `llms.txt`

Generated at build time at the root of your site (`/llms.txt`). Follows the [llms.txt spec](https://llmstxt.org/) — a plain-text index that AI tools and crawlers can read to understand your site structure.

```
# My Site

> The tagline from docusaurus.config.js

## Pages

- [Introduction](https://example.com/docs/intro): Getting started with the platform
- [API Reference](https://example.com/docs/api)
- ...
```

### Markdown endpoints

Every doc page is available as raw Markdown at `{permalink}.md`. For example:

```
/docs/intro       → rendered HTML page
/docs/intro.md    → raw Markdown source (great for LLM context)
```

This lets users, bots, and LLM tools fetch clean Markdown without scraping HTML.

### Copy page toolbar

A split button injected at the top-right of every doc page:

| Option | What it does |
|---|---|
| **Copy page** | Fetches the `.md` endpoint and copies the Markdown to clipboard |
| **View as Markdown** | Opens `/{path}.md` in a new tab |
| **Open in ChatGPT** | Opens `chatgpt.com` with the page URL pre-filled |
| **Open in Claude** | Opens `claude.ai/new` with the page URL pre-filled |

---

## Installation

```bash
npm install @writechoice/docusaurus-plugin-llms
```

---

## Usage

Add the plugin to `docusaurus.config.js`:

```js
export default {
  plugins: ['@writechoice/docusaurus-plugin-llms'],
};
```

That's it. The toolbar is injected automatically and `llms.txt` + `.md` files are generated on every build.

### With options

```js
export default {
  plugins: [
    [
      '@writechoice/docusaurus-plugin-llms',
      {
        generateLlmsTxt: true,       // default: true
        generateMarkdownFiles: true, // default: true
      },
    ],
  ],
};
```

| Option | Type | Default | Description |
|---|---|---|---|
| `generateLlmsTxt` | `boolean` | `true` | Write `/llms.txt` to the build output |
| `generateMarkdownFiles` | `boolean` | `true` | Copy source `.md` files to `/{permalink}.md` in the build output |

---

## How it works

### Build phase (`postBuild`)

After Docusaurus finishes building, the plugin:

1. Reads all doc metadata (`title`, `description`, `permalink`, `source`) from the docs plugin's content via `allContent`.
2. Writes `{outDir}/llms.txt` with a formatted list of all routes.
3. For each doc, copies its source `.md` file from `siteDir` to `{outDir}/{permalink}.md`.

### Theme

The plugin registers a theme path (`src/theme/`) which Docusaurus merges automatically. It provides two components:

- **`LLMSToolbar`** — the split button + dropdown React component
- **`DocItem/Layout`** — wraps Docusaurus's original `DocItem/Layout` via `@theme-original` to inject the toolbar above every doc page

No swizzling or extra configuration is required.

---

## Using the toolbar component directly

If you want to place the toolbar somewhere specific (e.g. in a custom swizzled layout), import it directly:

```jsx
import LLMSToolbar from '@theme/LLMSToolbar';

export default function MyLayout(props) {
  return (
    <>
      <LLMSToolbar />
      {/* ... */}
    </>
  );
}
```

To disable the automatic injection into `DocItem/Layout`, swizzle that component in your own project and omit the toolbar.

---

## Compatibility

| Docusaurus | Node | React |
|---|---|---|
| ≥ 3.0.0 | ≥ 18 | ≥ 18 |

---

## License

MIT
